# Sample .dasm files

The "dasm" directory contains samples of 
fully resolved assembly language files. 
Each foo.dasm corresponds to a foo.asm in the 
"asm" directory, and is an example of the
expected output of `assembler_phase1.py`. 

