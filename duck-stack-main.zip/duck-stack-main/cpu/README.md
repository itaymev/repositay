# The Duck Machine

A very basic, ultra-RISCy computer simulation project.

This repository is starter code for a project in CIS 211, Introduction
to Computer Science 2, at University of Oregon.

Add your bitfields.py to this directory, then follow 
instructions in docs/HOWTO-cpu.md . 

More documentation on the Duck Machine instruction set architecture is
in docs/duck_machine.md.


